package com.maskulka.zadanieo2

import io.cucumber.java8.En
import org.koin.core.context.startKoin
import org.koin.test.KoinTest

class KoinSetup : En, KoinTest {

//    init {
//        startKoin {
//            modules(
//                helloModule
//            )
//        }
//    }

}