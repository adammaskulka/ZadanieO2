package com.maskulka.zadanieo2

import com.maskulka.zadanieo2.model.CardState
import com.maskulka.zadanieo2.repository.ScratchCardRepository
import com.maskulka.zadanieo2.ui.dashboard.DashboardFragmentDirections
import com.maskulka.zadanieo2.ui.dashboard.DashboardViewModel
import com.maskulka.zadanieo2.utils.getStringResourceId
import com.maskulka.zadanieo2.utils.toStateFlow

import org.junit.Assert.*
import io.cucumber.java.After
import io.cucumber.java.Before
import io.cucumber.java.en.Given
import io.cucumber.java8.En
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.setMain
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runTest
import org.koin.test.KoinTest

@OptIn(ExperimentalCoroutinesApi::class)
class DashboardSteps: En, KoinTest {

    private lateinit var viewModel: DashboardViewModel

//    private val repository: ScratchCardRepository by inject()

    private val repository: ScratchCardRepository = mockk()

    private val cardStateChannel = Channel<CardState>()

    @Before
    fun setup() {
        Dispatchers.setMain(StandardTestDispatcher())

        coEvery { repository.observeScratchState() }.coAnswers { cardStateChannel.receiveAsFlow().toStateFlow(initialValue = CardState.New) }
    }

    @After
    fun tearDown() {
        Dispatchers.resetMain()
    }

    @Given("I open app")
    fun i_open_app() = runTest {
        cardStateChannel.send(CardState.New)
    }

    @Given("I am on dashboard")
    fun i_am_on_dashboard() = runTest {
        viewModel = DashboardViewModel(repository)
    }

    init {

        And("I see card state {string}") { arg: String ->
            runTest {
                val job = viewModel.state.onEach {
                    assert(it == arg.getStringResourceId())
                }.launchIn(this)
                job.cancel()
            }
        }

        And("scratch button is {string}") { arg: String ->
            val value = arg == "enabled"
            assert(viewModel.isScratchButtonEnabled.value == value)
        }

        And("activate button is {string}") { arg: String ->
            val value = arg == "enabled"
            assert(viewModel.isActivateButtonEnabled.value == value)
        }

        And("reset button is {string}") { arg: String ->
            val value = arg == "visible"
            assert(viewModel.isResetButtonVisible.value == value)
        }

        When("I click on Scratch button on dashboard") {
            viewModel.onScratchButtonClick()
        }

        When("I'm redirected to Scratch screen") {
            runTest {
                val job = viewModel.navDirections.onEach {
                    assert(it == DashboardFragmentDirections.navigateToScratchFragment())
                }.launchIn(this)
                job.cancel()
            }
        }

    }
}