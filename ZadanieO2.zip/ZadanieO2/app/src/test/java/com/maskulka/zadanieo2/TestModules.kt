package com.maskulka.zadanieo2

import com.maskulka.zadanieo2.managers.NotificationManager
import com.maskulka.zadanieo2.managers.ScratchCardManager
import com.maskulka.zadanieo2.network.ScratchCardApi
import com.maskulka.zadanieo2.repository.ScratchCardRepository
import com.nhaarman.mockitokotlin2.mock
import io.mockk.mockk
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.test.StandardTestDispatcher
import org.koin.dsl.module

val helloModule = module {

    single<ScratchCardApi> { mockk() }
    single<NotificationManager> { NotificationManager(mockk()) }
    single<ScratchCardRepository> { ScratchCardRepository(MainScope(), get(), get()) }
    single<ScratchCardManager> { ScratchCardManager(mock(), mock()) }

}