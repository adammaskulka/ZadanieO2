package com.maskulka.zadanieo2.repository

import com.maskulka.zadanieo2.managers.ScratchCardManager
import com.maskulka.zadanieo2.model.CardState
import com.maskulka.zadanieo2.network.CardActivationResponse
import com.maskulka.zadanieo2.network.NetworkResult
import com.maskulka.zadanieo2.network.ScratchCardApi
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import timber.log.Timber
import java.util.UUID


class ScratchCardRepository(
    private val applicationScope: CoroutineScope,
    private val api: ScratchCardApi,
    private val manager: ScratchCardManager
) {

    fun observeScratchState() = manager.scratchState

    private val _cardActivationState = MutableStateFlow<NetworkResult<Unit>>(NetworkResult.Init)
    val cardActivationState = _cardActivationState

    suspend fun scratchCard(): Flow<Result<String>> = flow {
        val code = withContext(Dispatchers.IO) {
            delay(3000L)
            UUID.randomUUID().toString()
        }

        manager.scratchCard(code)
        emit(Result.success(code))
    }

    suspend fun activateCard(): Flow<Result<CardActivationResponse>> = flow {
        _cardActivationState.value = NetworkResult.Loading
        val response = withContext(applicationScope.coroutineContext) {
            delay(5000L)

            val networkResponse = api.activateCard((manager.scratchState.value as CardState.Scratched).code)

            if (networkResponse.isSuccess) {
                val result = networkResponse.getOrThrow()
                manager.activateCard(result.android,
                    onActivationSuccess = {
                        _cardActivationState.value = NetworkResult.Success()
                    }, onActivationError = {
                        _cardActivationState.value = NetworkResult.Error()
                    })
            } else {
                _cardActivationState.value = NetworkResult.Error()
            }
            networkResponse
        }
        emit(response)
    }.catch {
        _cardActivationState.value = NetworkResult.Error()
        Timber.e("activateCard() error", it)
    }

    fun resetCardState() {
        manager.resetCardState()
        _cardActivationState.value = NetworkResult.Init
    }
}
