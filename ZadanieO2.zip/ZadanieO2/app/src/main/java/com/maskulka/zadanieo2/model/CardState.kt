package com.maskulka.zadanieo2.model

sealed class CardState {
    object New : CardState()
    class Scratched(val code: String) : CardState()
    object Activated : CardState()
}
