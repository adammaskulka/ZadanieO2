package com.maskulka.zadanieo2.utils

const val EMPTY_STRING = ""